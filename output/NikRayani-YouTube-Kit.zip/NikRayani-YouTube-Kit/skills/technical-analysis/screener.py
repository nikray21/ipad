#!/usr/bin/env python3
"""Screen both sides of the 50 SMA setup. Alpaca only. Stdlib only.

      export APCA_API_KEY_ID=...  APCA_API_SECRET_KEY=...
      python3 screener.py                 # the whole universe
      python3 screener.py SHOP UBER NVDA  # named symbols

LONG is the measured A-setup: 64% reach +4%, 48% reach +8%, +0.44R.
SHORT is the mirror and has NO measured edge (expectancy ~0, worse as the
downtrend steepens). It is printed because it was asked for, capped at C size.
"""
import json, os, sys, time, urllib.request, urllib.parse, datetime as dt
try:
    from zoneinfo import ZoneInfo
    ET = ZoneInfo("America/New_York")           # handles the EST/EDT switch
except Exception:
    ET = dt.timezone(dt.timedelta(hours=-4))    # EDT fallback

SLOPE_MIN = 1.5          # % move in the 50 SMA over 10 bars — below 1.0 the
                         # measured edge is zero, 1.0-1.5 is a grey band
VOL_BAND  = (1.5, 3.0)   # median 4h bar range as % of price
EXT_MAX   = 2.5          # max % the close may sit away from the SMA

UNIVERSE = """NVDA AMD AVGO MU INTC QCOM TSM ARM MRVL LRCX AMAT KLAC ASML ADI TXN
NXPI ON MCHP SMCI DELL AAPL MSFT GOOGL AMZN META NFLX TSLA ORCL CRM ADBE NOW PANW
CRWD ZS NET DDOG SNOW MDB TEAM WDAY PLTR APP SHOP UBER ABNB DASH RBLX U SOFI AFRM
HOOD COIN PYPL TTD SNAP PINS LYFT SPOT TOST DKNG RKLB LUNR ACHR JOBY OKLO SMR CEG
GEV VRT ANET VST TLN NBIS IREN RIOT MARA CLSK MSTR WULF CORZ LLY UNH HIMS TEM ISRG
CAT DE BA GE HON JPM GS BAC XOM CVX WMT COST NKE LULU DIS""".split()


# ---------------------------------------------------------------- data sources

def from_alpaca(symbols):
    """4h RTH bars from Alpaca.

    Alpaca has no 4H timeframe and no regular-hours filter on /bars, so bars are
    built from 30-minute bars. 30Min is the coarsest timeframe whose boundaries
    land on 09:30 and 13:30 -- an hourly bar stamped 09:00 straddles the open,
    mixing pre-market prints into the session high/low."""
    kid = os.environ.get("APCA_API_KEY_ID") or os.environ.get("ALPACA_API_KEY_ID")
    sec = os.environ.get("APCA_API_SECRET_KEY") or os.environ.get("ALPACA_API_SECRET_KEY")
    if not (kid and sec):
        sys.exit("APCA_API_KEY_ID / APCA_API_SECRET_KEY not set in the environment.")
    days = int(os.environ.get("ALPACA_DAYS", "140"))
    start = (dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=days)).strftime("%Y-%m-%d")
    feed = os.environ.get("ALPACA_FEED", "sip")   # sip = full tape; iex sees ~3% of it
    out, page = {}, None
    while True:
        q = {"symbols": ",".join(symbols), "timeframe": "30Min", "start": start,
             "limit": 10000, "adjustment": "split", "feed": feed}
        if page:
            q["page_token"] = page
        req = urllib.request.Request(
            "https://data.alpaca.markets/v2/stocks/bars?" + urllib.parse.urlencode(q),
            headers={"APCA-API-KEY-ID": kid, "APCA-API-SECRET-KEY": sec})
        for attempt in range(6):
            try:
                with urllib.request.urlopen(req, timeout=90) as r:
                    d = json.load(r)
                break
            except urllib.error.HTTPError as e:
                if e.code in (401, 403) and feed == "sip":
                    print("  ! no SIP entitlement — falling back to the IEX feed, which "
                          "sees ~3% of volume and prints different highs/lows",
                          file=sys.stderr)
                    feed = "iex"; d = None; break
                # 429 is a shared per-account budget, so a second process running
                # against the same key is enough to trip it. Back off and retry
                # rather than lose a fetch that is already minutes deep.
                if e.code == 429 or e.code >= 500:
                    wait = 2 ** attempt * 5
                    print(f"  ! HTTP {e.code} — retrying in {wait}s", file=sys.stderr)
                    time.sleep(wait); continue
                raise
            except (urllib.error.URLError, TimeoutError) as e:
                wait = 2 ** attempt * 5
                print(f"  ! {e} — retrying in {wait}s", file=sys.stderr)
                time.sleep(wait); continue
        else:
            raise RuntimeError("Alpaca kept failing after 6 attempts")
        if d is None:
            continue
        for sym, bars in (d.get("bars") or {}).items():
            out.setdefault(sym, []).extend(bars)
        page = d.get("next_page_token")
        if not page:
            break
    return {s: _to_4h(b) for s, b in out.items()}


# 4h bars sit on the UTC 4-hour grid (00/04/08/12/16/20), and the US session
# opens at 13:30 UTC. So the day splits at 16:00 UTC = NOON ET, not at the 13:30
# ET midpoint of the trading day:
#   bar 1  09:30-12:00 ET (2.5h, clipped by the open)
#   bar 2  12:00-16:00 ET (4h)
OPEN, MID, CLOSE = 9 * 60 + 30, 12 * 60, 16 * 60

def _to_4h(half_hourly):
    """Fold 30-minute bars into RTH 4h buckets: 09:30-13:30 and 13:30-16:00 ET.

    Drops the bucket still in progress. The A-setup is defined on a CLOSED 4h
    bar -- a live bar's low and close both still move, so grading one is the
    same error as reading the chart with the crosshair on it."""
    buckets = {}
    for b in half_hourly:
        t = dt.datetime.fromisoformat(b["t"].replace("Z", "+00:00"))
        et = t.astimezone(ET)
        mins = et.hour * 60 + et.minute
        if not OPEN <= mins < CLOSE:                 # regular hours only
            continue
        half = 0 if mins < MID else 1
        g = buckets.setdefault((et.date(), half),
                               {"h": -1e9, "l": 1e9, "c": None, "t": et})
        g["h"] = max(g["h"], b["h"]); g["l"] = min(g["l"], b["l"]); g["c"] = b["c"]

    now = dt.datetime.now(ET)
    rows = []
    for (day, half), v in sorted(buckets.items()):
        ends = dt.datetime.combine(day, dt.time(0), ET) + dt.timedelta(
            minutes=MID if half == 0 else CLOSE)
        if now < ends:                               # bucket still forming
            continue
        rows.append({"t": v["t"].isoformat(), "c": float(v["c"]),
                     "h": float(v["h"]), "l": float(v["l"])})
    return rows


# ------------------------------------------------------------------ indicators

def metrics(rows, back=0):
    if len(rows) < 61 + back:
        return None
    c = [r["c"] for r in rows]
    sma = lambda i: sum(c[i - 49:i + 1]) / 50
    i = len(rows) - 1 - back
    s_now, s_prev = sma(i), sma(i - 10)
    rng = sorted((r["h"] - r["l"]) / r["c"] * 100 for r in rows[i - 20:i])
    return {"px": c[i], "sma": s_now,
            "slope": (s_now - s_prev) / s_prev * 100,
            "ext": (c[i] - s_now) / s_now * 100,
            "range": rng[len(rng) // 2],
            "low": rows[i]["l"], "high": rows[i]["h"], "t": str(rows[i]["t"])[:16]}


def room(rows, side):
    """% to the first unbroken opposing pivot zone. Proxy for the LuxAlgo level —
    confirm on the chart before acting."""
    n, L, px = len(rows), 3, rows[-1]["c"]
    best = None
    for k in range(L, n - L):
        w = rows[k - L:k + L + 1]
        if side == "long":
            if rows[k]["h"] != max(x["h"] for x in w):
                continue
            if any(rows[j]["c"] > rows[k]["h"] for j in range(k + 1, n)):
                continue
            if rows[k]["l"] > px and (best is None or rows[k]["l"] < best):
                best = rows[k]["l"]
        else:
            if rows[k]["l"] != min(x["l"] for x in w):
                continue
            if any(rows[j]["c"] < rows[k]["l"] for j in range(k + 1, n)):
                continue
            if rows[k]["h"] < px and (best is None or rows[k]["h"] > best):
                best = rows[k]["h"]
    if best is None:
        return None
    return (best - px) / px * 100 * (1 if side == "long" else -1)


def live_price(symbols):
    """Last trade now. The setup is graded on a closed bar, but that bar can be
    hours old -- price may already have walked back through the SMA, which voids
    it. Real-time quotes need the IEX feed; SIP quotes are a paid entitlement."""
    kid = os.environ.get("APCA_API_KEY_ID") or os.environ.get("ALPACA_API_KEY_ID")
    sec = os.environ.get("APCA_API_SECRET_KEY") or os.environ.get("ALPACA_API_SECRET_KEY")
    try:
        req = urllib.request.Request(
            "https://data.alpaca.markets/v2/stocks/snapshots?" + urllib.parse.urlencode(
                {"symbols": ",".join(symbols), "feed": "iex"}),
            headers={"APCA-API-KEY-ID": kid, "APCA-API-SECRET-KEY": sec})
        with urllib.request.urlopen(req, timeout=30) as r:
            d = json.load(r)
        return {s: v["latestTrade"]["p"] for s, v in d.items()
                if (v or {}).get("latestTrade")}
    except Exception as e:
        print(f"  ! no live quote ({e}) -- setups below are as of the bar close only",
              file=sys.stderr)
        return {}


def touched(rows, back, side):
    m = metrics(rows, back)
    if not m:
        return False
    if side == "long":
        return m["low"] <= m["sma"] and m["px"] > m["sma"]
    return m["high"] >= m["sma"] and m["px"] < m["sma"]


def score(m, rm, age, side):
    s, why = 0, []
    ok = VOL_BAND[0] <= m["range"] <= VOL_BAND[1]
    s += 2 if ok else 0
    why.append(("Eligible name", 2 if ok else 0, f"{m['range']:.1f}%/bar"))
    sl = abs(m["slope"])
    p = 2 if sl >= 1.5 else 1 if sl >= 1.0 else 0
    s += p; why.append(("SMA slope", p, f"{m['slope']:+.1f}% / 10 bars"))
    p = 2 if age == 0 else 1 if age == 1 else 0
    s += p; why.append(("The bounce", p, "this bar" if age == 0 else "prev bar"))
    p = 1 if abs(m["ext"]) <= EXT_MAX else 0
    s += p; why.append(("Not extended", p, f"{m['ext']:+.1f}% vs SMA"))
    p = 2 if (rm is None or rm >= 8) else 1 if rm >= 4 else 0
    s += p; why.append(("Room", p, "clear air" if rm is None else f"{rm:+.1f}% to zone"))
    why.append(("Book & calendar", "?", "verify earnings + book"))
    return s, why


# ----------------------------------------------------------------------- main

def main(argv):
    syms = [a for a in argv if a.isupper() and a.isalpha()] or UNIVERSE
    bars, src = {}, "ALPACA " + os.environ.get("ALPACA_FEED", "sip").upper()
    for i in range(0, len(syms), 50):
        bars.update(from_alpaca(syms[i:i + 50]))
    rows = {s: m for s, m in ((s, metrics(r)) for s, r in bars.items()) if m}
    if not rows:
        print("no bar data"); return
    print(f"source: {src} — scanned {len(rows)} names, last closed bar "
          f"{next(iter(rows.values()))['t']}\n")

    for side in ("long", "short"):
        takes, armed = [], []
        for s, m in sorted(rows.items()):
            if not VOL_BAND[0] <= m["range"] <= VOL_BAND[1]:
                continue
            steep = (m["slope"] >= SLOPE_MIN) if side == "long" else (m["slope"] <= -SLOPE_MIN)
            right = (m["px"] > m["sma"]) if side == "long" else (m["px"] < m["sma"])
            if not (steep and right):
                continue
            age = 0 if touched(bars[s], 0, side) else 1 if touched(bars[s], 1, side) else None
            if age is not None and abs(m["ext"]) <= EXT_MAX:
                takes.append((s, m, age))
            elif age is None:
                armed.append((s, m))

        live = live_price([s for s, _, _ in takes]) if takes else {}
        tag = "LONG — the measured A-setup" if side == "long" else \
              "SHORT — mirror setup, NO measured edge (E~0), C size max"
        print(f"=== {tag} ===")
        print("SETUPS")
        if not takes:
            print("  none")
        for s, m, age in takes:
            rm = room(bars[s], side)
            sc, why = score(m, rm, age, side)
            grade = "A" if sc >= 9 else "B" if sc >= 7 else "C" if sc >= 5 else "D"
            d = 1 if side == "long" else -1
            stop = m["px"] * (1 - .04 * d)
            if rm is None or rm >= 8:                    # clear to +8%
                plan, tgt = "RUNNER 1:2", m["px"] * (1 + .08 * d)
            elif rm >= 4:                                # a zone caps it at +4%
                plan, tgt = "SCALP 1:1", m["px"] * (1 + .04 * d)
            else:                                        # nothing worth taking
                plan, tgt = "SKIP — no room", None
            now = live.get(s)
            if now is not None:
                gone = (now < m["sma"]) if side == "long" else (now > m["sma"])
                mark = (f"  *** VOID — now ${now:.2f}, back through the SMA ***" if gone
                        else f"  (live ${now:.2f}, still holding)")
            else:
                mark = ""
            print(f"  {s:<6} ${m['px']:.2f}  {sc}/10 {grade}  {plan}{mark}")
            print(f"         slope {m['slope']:+.1f}%  ext {m['ext']:+.1f}%  "
                  f"range {m['range']:.1f}%/bar  touch {'this' if age==0 else 'prev'} bar"
                  f"  room {'clear' if rm is None else f'{rm:+.1f}%'}")
            t = "—" if tgt is None else f"${tgt:.2f}"
            print(f"         stop ${stop:.2f}   target {t}")
        print("\nARMED (steep trend, waiting for the pullback to the SMA)")
        if not armed:
            print("  none")
        for s, m in sorted(armed, key=lambda x: abs(x[1]["ext"]))[:10]:
            verb = "dip to" if side == "long" else "pop to"
            print(f"  {s:<6} ${m['px']:.2f}  {m['ext']:+.1f}% vs SMA — needs a {verb} "
                  f"${m['sma']:.2f} and a close back {'above' if side=='long' else 'below'}"
                  f"  (slope {m['slope']:+.1f}%)")
        print()


if __name__ == "__main__":
    main(sys.argv[1:])
